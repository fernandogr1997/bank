<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Spei extends Model
{
    use HasFactory;

    protected $table= 'spei';

    protected $fillable = [
        'banco_nombre',
        'beneficiario',
        'clave',
        'codigo_swift',
        'estatus',
    ];
    
    protected $casts = [
        'estatus' => 'boolean',
    ];
}
