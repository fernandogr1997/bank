<?php

namespace App\Http\Controllers;

use App\Models\Paypal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PaypalController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        // $page = $request->input('page');
        // $int_start = $request->input('start');
        // $int_limit = $request->input('limit');
        // $json_filter = $request->input('filter');

        // Convertir el filtro de JSON a un array asociativo
        // $array_filter = json_decode($json_filter, true);

        // $query = Vendedor::query();

        // Aplicar filtros si están presentes
        // if ($array_filter) {
        //     foreach ($array_filter as $filterItem) {
        //         $str_property = $filterItem['property'];
        //         $str_operator = $filterItem['operator'];
        //         $str_value = $filterItem['value'];

        //         // Aplicar el filtro a la consulta
        //         $query->where($str_property, $str_operator, '%'.$str_value.'%');
        //     }
        // }

        // Obtener los resultados paginados
        // $array_data = $query->skip($int_start)->take($int_limit)->where('estatus', 1)->get();
        
        // $Devoluciones = Devolucion::where('estatus', 1)->get();

        // return $Devoluciones;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {


        // // Traer datos existentes con estatus igual a 1 (activos)
        // $existencias = Area::where('estatus', 1)->get();

        // // Validar si existe un duplicado en linea
        // $duplicadoClave = $existencias->where('clave', $request->clave)
        //     ->first();

        // if ($duplicadoClave) {
        //     // Registro duplicado encontrado
        //     return response()->json(['message' => 'No se puede actualizar debido a la existencia de duplicados'], 422);
        // }

        // // Validar si existe un duplicado en linea
        // $duplicadoArea = $existencias->where('area', $request->area)
        //     ->first();

        // if ($duplicadoArea) {
        //     // Registro duplicado encontrado
        //     return response()->json(['message' => 'No se puede actualizar debido a la existencia de duplicados'], 422);
        // }

        // $validator = Validator::make($request->all(),[
        //     'vendedor' => 'required|string|',
        //     'id_cliente' => 'required|string',
        //     'id_venta' => 'required|string',
        //     'pieza' => 'required',
        //     'gramos' => 'required',
            

        // ],[
        //     'vendedor.required' => 'Campo Vendedor es obligatorio',
        //     'id_cliente.required' => 'Campo cliente es obligatorio',
        //     'id_venta.required' => 'Campo de Venta es obligatorio',  
        //     'pieza.required' => 'Campo pieza es obligatorio',
        //     'gramos.required' => 'Campo gramos es obligatorio',  
              
        // ]);

        // if($validator->fails()){
        //     return response()->json($validator->errors());
        // }

        // //Para crear nuevo registro
        // $Devoluciones = new Devolucion();
        // $Devoluciones->vendedor = $request->vendedor;
        // $Devoluciones->id_cliente = $request->id_cliente;
        // $Devoluciones->id_venta = $request->id_venta;
        // $Devoluciones->pieza = $request->pieza;
        // $Devoluciones->gramos = $request->gramos;
        // $Devoluciones->estatus = 1;

        // $Devoluciones->save();

        // return response()->json(['respuesta' => 'Datos guardados exitosamente.'], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        // $Devolucion = Devolucion::find($id);
        // return $Devolucion;
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */

    public function update(Request $request, string $id)
    {


        //     // Traer datos existentes con estatus igual a 1 (activos)
        //     $existencias = Area::where('estatus', 1)->get();

        //    // Validar si existe un duplicado en linea
        //    $duplicadoClave = $existencias->where('clave', $request->clave)
        //    ->where('id', '!=', $id) // Excluir el registro actual
        //        ->first();

        //    if ($duplicadoClave) {
        //        // Registro duplicado encontrado
        //        return response()->json(['message' => 'No se puede actualizar debido a la existencia de duplicados'], 422);
        //    }

        //    // Validar si existe un duplicado en linea
        //    $duplicadoArea = $existencias->where('area', $request->area)
        //    ->where('id', '!=', $id) // Excluir el registro actual
        //        ->first();

        //    if ($duplicadoArea) {
        //        // Registro duplicado encontrado
        //        return response()->json(['message' => 'No se puede actualizar debido a la existencia de duplicados'], 422);
        //    }

        // $Devolucion = Devolucion::findOrFail($id);

        // $Devolucion->fill($request->only([
        //     'vendedor',
        //     'id_cliente',
        //     'id_venta',
        //     'pieza',
        //     'gramos',
        // ]));

        // $Devolucion->save();

        // return response()->json(['respuesta' => 'Datos Actualizados exitosamente.'], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {

        // $Devolucion = Devolucion::findOrFail($id);

        // if ($Devolucion->estatus == 1) {

        //     $Devolucion->estatus = 0;
        //     $Devolucion->save();

        //     return response()->json(['respuesta' => true], 200);
        // }
    }
}
