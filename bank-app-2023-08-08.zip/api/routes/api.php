<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\EventsController;
use App\Http\Controllers\HistorysController;
use App\Http\Controllers\PaypalController;
use App\Http\Controllers\SpeiController;
use App\Http\Controllers\StripeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::controller(AuthController::class)->group(function () {
    Route::post('/register', 'register');
    Route::post('/login', 'login');
    Route::get('/token', 'token');

});



Route::prefix('events')->group(function () {
    Route::controller(EventsController::class)->group(function () {
        Route::get('/index','index'); 
        Route::post('/store','store');
        Route::get('/show/{id}','show');
        Route::put('/update/{id}','update');
        Route::delete('/destroy/{id}','destroy');
    });
});
Route::prefix('history')->group(function () {
    Route::controller(HistorysController::class)->group(function () {
        Route::get('/index','index'); 
        Route::post('/store','store');
        Route::get('/show/{id}','show');
        Route::put('/update/{id}','update');
        Route::delete('/destroy/{id}','destroy');
    });
});
Route::prefix('paypal')->group(function () {
    Route::controller(PaypalController::class)->group(function () {
        Route::get('/index','index'); 
        Route::post('/store','store');
        Route::get('/show/{id}','show');
        Route::put('/update/{id}','update');
        Route::delete('/destroy/{id}','destroy');
    });
});
Route::prefix('spei')->group(function () {
    Route::controller(SpeiController::class)->group(function () {
        Route::get('/index','index'); 
        Route::post('/store','store');
        Route::get('/show/{id}','show');
        Route::put('/update/{id}','update');
        Route::delete('/destroy/{id}','destroy');
    });
});
Route::prefix('stripe')->group(function () {
    Route::controller(StripeController::class)->group(function () {
        Route::get('/index','index'); 
        Route::post('/store','store');
        Route::get('/show/{id}','show');
        Route::put('/update/{id}','update');
        Route::delete('/destroy/{id}','destroy');
    });
});


Route::middleware(['auth:sanctum'])->group(function () {
      
    Route::get('/logout',[AuthController::class, 'logout']);
});