
//local
export const backendApi = 'http://localhost/bank-app/api/public/api';
export const DocumentApi = 'http://localhost/bank-app';

//produccion server
// export const backendApi = 'https://culturacrm.website/api/public/api';
// export const DocumentApi = 'https://culturacrm.website';
