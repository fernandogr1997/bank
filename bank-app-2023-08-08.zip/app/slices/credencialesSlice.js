import { createSlice } from '@reduxjs/toolkit';
import Cookies from 'js-cookie';

const initialState = {
  status: 'checking',
  token: '',
  getDatos: false,
  vendedores: false,
  Comentarios: false,
  ventas: false,
  devoluciones: false,
}


export const credencialesSlice = createSlice({
  name: 'credenciales',
  initialState,
  reducers: {
    login: (state, {payload}) => {
      state.status = 'autenticado';
      state.token = payload;
    },
    logout:(state) => {
      Cookies.remove('email');
      Cookies.remove('permisos');
      Cookies.remove('user');
      Cookies.remove('token');
      
      state.status = 'no-autenticado';
      state.token = '';
    },
    actualizarDashboard: (state) => {
      if(state.getDatos === false){
        state.getDatos = true;
      }else if(state.getDatos === true){
        state.getDatos = false;
      }
    },
    actualizarComentarios: (state) => {
      if(state.Comentarios === false){
        state.Comentarios = true;
      }else if(state.Comentarios === true){
        state.Comentarios = false;
      }
    },
    actualizarTablaVendedores: (state) => {
      if(state.vendedores === false){
        state.vendedores = true;
      }else if(state.vendedores === true){
        state.vendedores = false;
      }
    },actualizarTablaVentas: (state) => {
      if(state.ventas === false){
        state.ventas = true;
      }else if(state.ventas === true){
        state.ventas = false;
      }
    },
    actualizarTablaDevoluciones: (state) => {
      if(state.devoluciones === false){
        state.devoluciones = true;
      }else if(state.devoluciones === true){
        state.devoluciones = false;
      }
    },

    checkingCredentials: (state) => {
      state.status = 'checking';
    },
    verdato: (state ,{payload}) => {
      console.log(payload);
    }
    
  },
})

// Action creators are generated for each case reducer function
export const { 
  checkingCredentials,
  login,
  logout,
  actualizarDashboard,
  actualizarTablaVendedores,
  actualizarComentarios,
  actualizarTablaVentas,
  actualizarTablaDevoluciones,
  verdato } = credencialesSlice.actions

export default credencialesSlice.reducer